package com.artisan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.artisan.model.NewsType;
import com.artisan.model.lowUser;

public class lowUserDao {
	
	public lowUser login(Connection con,lowUser lowuser)throws Exception{
		lowUser resultUser=null;
		String sql="select * from t_lowuser where userName=? and password=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, lowuser.getUsername());
		pstmt.setString(2, lowuser.getPassword());
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			resultUser=new lowUser();
			resultUser.setUsername(rs.getString("username"));
			resultUser.setPassword(rs.getString("password"));
		}
		return resultUser;
	}
	
	
	public boolean register(Connection con,lowUser lowuser) throws SQLException{
		String select_sql = "select * from t_lowuser where username=?";
		PreparedStatement select_pstmt = con.prepareStatement(select_sql);
		select_pstmt.setString(1, lowuser.getUsername());
		ResultSet select_rs = select_pstmt.executeQuery();
		if(select_rs.next()){
			return false;
		}
		String sql = "insert into t_lowuser (username,password) values (?,?)";
		PreparedStatement pstmt;
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, lowuser.getUsername());
		pstmt.setString(2, lowuser.getPassword());
		
		int rs = pstmt.executeUpdate();
		if(rs==1){
			return true;
		}
		return false;
	}
	
	
	public List<lowUser> newsUserList(Connection con)throws Exception{
		List<lowUser> newsUserList=new ArrayList<lowUser>();
		String sql="select * from t_lowuser";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()){
			lowUser lowUser=new lowUser();
			
			lowUser.setUserid(rs.getInt(1));
			lowUser.setUsername(rs.getString(2));
			lowUser.setPassword(rs.getString(3));
			lowUser.setName(rs.getString(4));
			newsUserList.add(lowUser);
		}
		return newsUserList;
	}
	
	public boolean existNewsWithNewsTypeId(Connection con,String typeId)throws Exception{
		String sql="select * from t_users where typeId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, typeId);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			return true;
		}else{
			return false;
		}
	}
	
	public int usersDelete(Connection con,String newsId)throws Exception{
		String sql="delete from t_lowuser where userid=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, newsId);
		return pstmt.executeUpdate();
	}
	
	
	public boolean usersUpdate(Connection con,lowUser lowUser)throws Exception{
		String sql="update t_lowuser set  username=?,password=? where userid=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, lowUser.getUsername());
		pstmt.setString(2, lowUser.getPassword());
		pstmt.setInt(3, lowUser.getUserid());
		int i = pstmt.executeUpdate();
		return i==0?false:true;
	}
	
	public lowUser getUserById(Connection con,int userid)throws Exception{
		lowUser lowUser=new lowUser();
		String sql="select * from t_lowuser where userid=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, userid);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			lowUser.setUserid(rs.getInt("userid"));
			lowUser.setUsername(rs.getString("username"));
			lowUser.setPassword(rs.getString("password"));
		}
		return lowUser;
	}
	
}