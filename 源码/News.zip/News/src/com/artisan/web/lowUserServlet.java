package com.artisan.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import com.artisan.dao.UserDao;
import com.artisan.dao.lowUserDao;
import com.artisan.model.NewsType;
import com.artisan.model.User;
import com.artisan.model.lowUser;
import com.artisan.util.DbUtil;
import com.artisan.util.NavUtil;
import com.artisan.util.ResponseUtil;
import com.artisan.util.StringUtil;

public class lowUserServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DbUtil dbUtil=new DbUtil();
	lowUserDao lowUserDao=new lowUserDao();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//��ȡ����
		String action=request.getParameter("action");
		if("login".equals(action)){
			login(request,response);
		}else if("logout".equals(action)){
			logout(request,response);
		}else if("Register".equals(action)){
			register(request, response);
		}else if("backList".equals(action)){
			this.newsUserBackList(request, response);
		}else if("delete".equals(action)){
			this.userDelete(request, response);
		}else if("save".equals(action)){
			this.newsUserSave(request, response);
		}else if("preSave".equals(action)){
			this.newsUserPreSave(request, response);
		}
		
	}
	
	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		
		HttpSession session=request.getSession();
		Connection con=null;
		try{
			con=dbUtil.getCon();
			lowUser lowuser=new lowUser(userName,password);
			lowUser currentUser=lowUserDao.login(con, lowuser);
			//System.out.println(currentUser.toString());
			if(currentUser==null){
				request.setAttribute("error", "�û��������������");
				request.setAttribute("password", password);
				request.setAttribute("userName", userName);
				request.getRequestDispatcher("/foreground/lowusers/login.jsp").forward(request, response);
			}else{
				//System.out.println(currentUser.toString());
//				session.setAttribute("currentUser", currentUser);
				session.setAttribute("currentUser", currentUser);
				//request.setAttribute("mainPage", "/background/default.jsp");
				request.getRequestDispatcher("/foreground/newsTemp.jsp").forward(request, response);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void register(HttpServletRequest request, HttpServletResponse response)
		throws ServletException,IOException{
		String userName=request.getParameter("userName");
		String password=request.getParameter("passWord");
		lowUser lowuser=new lowUser(userName,password);
		HttpSession session=request.getSession();
		JSONObject result=new JSONObject();
		Connection con=null;
		try {
			con = dbUtil.getCon();
			boolean flag = lowUserDao.register(con, lowuser);
			System.out.println(flag);
			if(flag){
				result.put("success", true);
			}else{
				result.put("errorMsg", "ע��ʧ��");
				request.setAttribute("error", "ע��ʧ��");
				request.getRequestDispatcher("/foreground/register.jsp").forward(request, response);
			}
			ResponseUtil.write(result, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
	public void logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().invalidate();
		System.out.println(request.getContextPath()+"/background/login.jsp");
		response.sendRedirect(request.getContextPath()+"/background/login.jsp");
	}
	
	
	public void newsUserBackList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection con=null;
		try{
			con=dbUtil.getCon();
			List<lowUser> newsUserBackList=lowUserDao.newsUserList(con);
			request.setAttribute("newsUserBackList", newsUserBackList);
			request.setAttribute("navCode", NavUtil.genNewsManageNavigation("�û��˺Ź���","�û��˺�ά��  "));
			request.setAttribute("mainPage", "/background/users/users.jsp");
			request.getRequestDispatcher("/background/mainTemp.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void userDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userId=request.getParameter("userid");
		Connection con=null;
		try{
			con=dbUtil.getCon();
			JSONObject result=new JSONObject();
			int delNums=lowUserDao.usersDelete(con, userId);
			if(delNums>0){
				result.put("success", true);
			}else{
				result.put("errorMsg", "ɾ��ʧ��");
			}
			ResponseUtil.write(result, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	//Ԥ����
	private void newsUserPreSave(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userid=request.getParameter("userid");
		Connection con=null;
		try{
			con=dbUtil.getCon();
			if(StringUtil.isNotEmpty(userid)){
				//���id��Ϊ�յĻ�  ȡ����Ӧid��ֵ��
				lowUser lowUser=lowUserDao.getUserById(con, Integer.parseInt(userid));
				//�Ѷ�Ӧid��ֵ����ȥ��
				request.setAttribute("lowUser", lowUser);
			}
			
			if(StringUtil.isNotEmpty(userid)){
				request.setAttribute("navCode", NavUtil.genNewsManageNavigation("�û��˺Ź���", "�û��˺��޸�"));
			}else{
				//request.setAttribute("navCode", NavUtil.genNewsManageNavigation("����������", "�����������"));
			}
			request.setAttribute("mainPage", "/background/users/usersave.jsp");
			request.getRequestDispatcher("/background/mainTemp.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//����
	private void newsUserSave(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection con=null;
		String userid=request.getParameter("userid");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		System.out.println(userid);
		System.out.println(username);
		System.out.println(password);
		lowUser lowUser=new lowUser(Integer.parseInt(userid),username,password);
		
//		if(StringUtil.isNotEmpty(newsTypeId)){
//			newsType.setNewsTypeId(Integer.parseInt(newsTypeId));
//		}
		try{
			con=dbUtil.getCon();
			if(StringUtil.isNotEmpty(userid)){
				lowUserDao.usersUpdate(con, lowUser);
			}else{
				//newsTypeDao.newsTypeAdd(con, newsType);
			}
			request.getRequestDispatcher("/lowusers?action=backList").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
